<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateSampleReceivingRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        $category = $this->route('category');
        return [
            'date' => 'required|date',
            'time' => 'required|date_format:H:i',
            'section' => 'required|integer|exists:sample_categories,id',
            'client_name' => 'required|string|max:255',
            'client_reference' => 'required|string|max:255',
            'type_of_sample' => 'required|string|max:255',
            'required_tests' => 'required|string|max:255',
            'number_of_sample' => 'required|string|max:255',
            'delivered_by' => 'required|integer|exists:employees,id',
            'received_by' => 'required|integer|exists:employees,id'
        ];
    }
}
