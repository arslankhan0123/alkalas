<?php

namespace App\Http\Requests;

use App\Models\VehicleRental;
use Illuminate\Foundation\Http\FormRequest;

class VehicleRentalRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return VehicleRental::rules();
    }

    public function messages()
    {
        return VehicleRental::messages();
    }
}
